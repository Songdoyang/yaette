package com.fit.Ya_eottae;

public interface SessionConst {

    String SESSION_ID = "loginSessionId";
}
