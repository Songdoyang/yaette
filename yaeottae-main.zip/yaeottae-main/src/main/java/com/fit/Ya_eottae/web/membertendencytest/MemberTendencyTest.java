package com.fit.Ya_eottae.web.membertendencytest;

import com.fit.Ya_eottae.web.membertendencytest.question.*;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class
MemberTendencyTest {

    private TendencyQuestion1 answer1;
    private TendencyQuestion2 answer2;
    private TendencyQuestion3 answer3;
    private TendencyQuestion4 answer4;
    private TendencyQuestion5 answer5;
}
