package com.fit.Ya_eottae.domain.restaurant.region;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class AreaCode {

    private String code;
    private String codeName;

}
