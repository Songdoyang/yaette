package com.fit.Ya_eottae;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YaEottaeApplicationTests {

	@Test
	void contextLoads() {
	}

}
